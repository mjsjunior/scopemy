jQuery(function() {
	parent.iframeCallback( jQuery.support );
});
