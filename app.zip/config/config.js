module.exports = {

    'secret': 'ilovesocpemyapp',
    'database': 'mongodb://localhost/scopemy-dev'

};